import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { CinemaPresentation, type Slide } from "@/components/CinemaPresentation";
import { siteContentQuery } from "@/lib/site-content.functions";
import { isNew, type SiteContent } from "@/lib/site-content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dr. Fatima Elzahraa Ahmed — Dental Portfolio" },
      {
        name: "description",
        content:
          "Clinical portfolio of Dr. Fatima Elzahraa Ahmed: endodontics, operative, pedo, surgery and prosthodontics cases from Minya, Egypt.",
      },
      { property: "og:title", content: "Dr. Fatima Elzahraa Ahmed — Dental Portfolio" },
      {
        property: "og:description",
        content:
          "Dedicated professional dentist — selected clinical cases, documented from first radiograph to final result.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(siteContentQuery),
  component: Index,
});

const ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];

function buildSlides(s: SiteContent, cases: SiteContent["cases"]): Slide[] {
  const p = s.presentation;
  const extra = (pos: "start" | "end") =>
    p.extra
      .filter((x) => x.position === pos)
      .map((x) => ({ img: x.img || undefined, eyebrow: x.eyebrow, title: x.title, text: x.text }));
  const out: Slide[] = [...extra("start")];
  if (p.show_intro)
    out.push({
      img: s.hero_image,
      eyebrow: "A Clinical Portfolio",
      title: (
        <>
          <em>{s.first_name}</em>
          <br />
          <span className="text-gold">{s.last_name}</span>
        </>
      ),
      text: (
        <>
          <p dir="rtl" className="font-arabic text-xl text-primary">
            {s.name_ar}
          </p>
          <p className="mt-2 eyebrow text-muted-foreground">{s.hero_eyebrow}</p>
        </>
      ),
    });
  if (p.show_portrait)
    out.push({
      img: s.portrait,
      eyebrow: "The Doctor",
      title: <em className="text-gold">{s.first_name}</em>,
      text: s.about_quote,
    });
  if (p.show_disciplines)
    s.disciplines.forEach((d, k) =>
      out.push({
        eyebrow: `Discipline ${ROMAN[k] ?? k + 1}`,
        title: <em className="text-gold">{d.t}</em>,
        text: d.d,
      }),
    );
  if (p.show_cases)
    cases.forEach((c, k) =>
      out.push({
        img: c.img,
        contain: true,
        eyebrow: `Case No. ${String(k + 1).padStart(2, "0")} · ${c.c}`,
        title: c.t,
        text: c.d,
      }),
    );
  out.push(...extra("end"));
  if (p.show_contact)
    out.push({
      img: s.hero_image,
      eyebrow: "Appointments",
      title: <em className="text-gold">{s.contact_title}</em>,
      text: <p className="font-display text-2xl text-foreground">{s.phone_label}</p>,
    });
  return out;
}

function Index() {
  const { data: s } = useSuspenseQuery(siteContentQuery);
  const cases = useMemo(() => s.cases.filter((c) => !c.hidden), [s.cases]);
  const cats = ["All", ...s.categories];
  const [cinema, setCinema] = useState(false);
  const [newCount, setNewCount] = useState(0);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    document.documentElement.classList.remove("theme-gold", "theme-rose", "theme-navy");
    document.documentElement.classList.add("scroll-smooth", `theme-${s.theme}`);
  }, [s.theme]);

  useEffect(() => {
    if (s.presentation.autoplay && !sessionStorage.getItem("cinemaSeen")) {
      sessionStorage.setItem("cinemaSeen", "1");
      setCinema(true);
    }
    // "New case" notice for returning visitors
    const last = localStorage.getItem("lastVisit");
    if (last)
      setNewCount(cases.filter((c) => new Date(c.added_at).getTime() > Number(last)).length);
    localStorage.setItem("lastVisit", String(Date.now()));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const [filter, setFilter] = useState("All");
  const [openId, setOpenId] = useState<string | null>(null);
  const shown = useMemo(
    () => cases.map((c, i) => ({ ...c, i })).filter((c) => filter === "All" || c.c === filter),
    [cases, filter],
  );
  const openIndex = shown.findIndex((c) => c.id === openId);
  const active = openIndex >= 0 ? shown[openIndex] : null;

  useEffect(() => {
    if (openId === null || openIndex < 0) return;
    const step = (direction: number) => {
      const next = (openIndex + direction + shown.length) % shown.length;
      setOpenId(shown[next]!.id);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpenId(null);
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [openId, openIndex, shown]);

  const tel = `tel:${s.phone}`;
  return (
    <main
      className={`theme-${s.theme} min-h-screen overflow-x-hidden bg-background text-foreground`}
    >
      <header className="fixed inset-x-0 top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-3">
          <a
            href="#top"
            onClick={() => setMenu(false)}
            className="font-script text-2xl text-primary"
          >
            {s.brand}
          </a>
          <nav
            aria-label="Main navigation"
            className="hidden gap-8 text-xs uppercase tracking-[0.3em] text-muted-foreground md:flex"
          >
            <a href="#about" className="hover:text-primary">
              About
            </a>
            <a href="#expertise" className="hover:text-primary">
              Expertise
            </a>
            <a href="#cases" className="hover:text-primary">
              Cases
            </a>
            <a href="#contact" className="hover:text-primary">
              Contact
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <button
              type="button"
              aria-label={menu ? "Close navigation" : "Open navigation"}
              aria-expanded={menu}
              aria-controls="mobile-navigation"
              onClick={() => setMenu((value) => !value)}
              className="h-9 w-9 rounded-full border border-border text-lg md:hidden"
            >
              {menu ? "×" : "☰"}
            </button>
            <a
              href={tel}
              className="rounded-full bg-gold px-5 py-2 text-xs uppercase tracking-[0.25em] text-primary-foreground"
            >
              Call
            </a>
          </div>
        </div>
        {menu && (
          <nav
            id="mobile-navigation"
            aria-label="Mobile navigation"
            className="grid grid-cols-2 gap-2 border-t border-border bg-background/95 px-5 py-4 text-center text-xs uppercase tracking-[0.2em] text-muted-foreground md:hidden"
          >
            {[
              ["About", "#about"],
              ["Expertise", "#expertise"],
              ["Cases", "#cases"],
              ["Contact", "#contact"],
            ].map(([label, href]) => (
              <a
                key={href}
                href={href}
                onClick={() => setMenu(false)}
                className="rounded-lg border border-border px-3 py-3 hover:border-primary hover:text-primary"
              >
                {label}
              </a>
            ))}
          </nav>
        )}
      </header>

      {newCount > 0 && (
        <div
          role="status"
          className="fixed inset-x-4 top-16 z-40 mx-auto flex max-w-md items-center justify-between gap-3 rounded-full border border-primary/40 bg-background/95 px-5 py-2.5 text-sm shadow-soft backdrop-blur animate-rise"
        >
          <a
            href="#cases"
            onClick={() => {
              setNewCount(0);
              setFilter("All");
            }}
            className="flex-1"
          >
            ✦ {newCount === 1 ? "A new case was added" : `${newCount} new cases were added`} —{" "}
            <span className="text-primary underline">see it</span>
          </a>
          <button
            aria-label="Dismiss"
            onClick={() => setNewCount(0)}
            className="text-muted-foreground"
          >
            ✕
          </button>
        </div>
      )}

      <section
        id="top"
        className="relative flex min-h-[100svh] items-end overflow-hidden pb-20 pt-28 md:items-center"
      >
        {s.hero_image ? (
          <img
            src={s.hero_image}
            alt=""
            className="absolute inset-0 h-full w-full object-cover object-[70%_center] opacity-70"
          />
        ) : (
          <div className="absolute inset-0 bg-plum" />
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        <div className="relative mx-auto w-full max-w-6xl px-5 animate-rise">
          <p className="eyebrow">{s.hero_eyebrow}</p>
          <h1 className="mt-6 break-words text-5xl leading-[0.95] sm:text-6xl md:text-8xl">
            <em className="font-display">{s.first_name}</em>
            <br />
            <span className="text-gold">{s.last_name}</span>
          </h1>
          <p className="mt-6 max-w-md text-base font-light leading-relaxed text-muted-foreground md:text-lg">
            {s.hero_text}
          </p>
          <p dir="rtl" className="mt-3 font-arabic text-lg text-primary">
            {s.name_ar} — {s.hero_text_ar}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <button
              onClick={() => setCinema(true)}
              className="rounded-full bg-gold px-7 py-3 text-xs uppercase tracking-[0.25em] text-primary-foreground shadow-soft"
            >
              ▶ Play the presentation
            </button>
            <a
              href="#cases"
              className="rounded-full border border-border px-7 py-3 text-xs uppercase tracking-[0.25em] hover:border-primary hover:text-primary"
            >
              View the cases
            </a>
          </div>
        </div>
      </section>

      {s.marquee.length > 0 && (
        <div className="overflow-hidden border-y border-border py-5">
          <div className="flex w-max animate-marquee gap-10 font-display text-2xl italic text-muted-foreground md:text-3xl">
            {[...s.marquee, ...s.marquee].map((m, i) => (
              <span key={i} className="flex items-center gap-10">
                {m}
                <span className="text-primary">✦</span>
              </span>
            ))}
          </div>
        </div>
      )}

      <section
        id="about"
        className="mx-auto grid max-w-6xl scroll-mt-20 gap-12 px-5 py-24 md:grid-cols-[0.8fr_1.2fr] md:items-center"
      >
        <div className="relative mx-auto w-full max-w-sm">
          <div className="absolute -inset-3 rounded-[2rem] border border-primary/40" />
          {s.portrait ? (
            <img
              src={s.portrait}
              alt={`${s.first_name} ${s.last_name}`}
              className="relative aspect-[4/5] w-full rounded-[1.6rem] object-cover object-[72%_28%] shadow-soft"
            />
          ) : (
            <div className="relative grid aspect-[4/5] w-full place-items-center rounded-[1.6rem] bg-plum font-script text-6xl text-primary shadow-soft">
              {s.first_name}
            </div>
          )}
        </div>
        <div>
          <p className="eyebrow">The Doctor</p>
          <h2 className="mt-3 font-script text-5xl text-primary md:text-6xl">
            {s.first_name} {s.last_name.split(" ")[0]}
          </h2>
          <p dir="rtl" className="mt-1 text-left font-arabic text-xl text-muted-foreground">
            {s.name_ar}
          </p>
          <blockquote className="mt-8 font-display text-3xl leading-snug md:text-4xl">
            “{s.about_quote}”
          </blockquote>
          <p className="mt-6 whitespace-pre-line font-light leading-relaxed text-muted-foreground">
            {s.about_text}
          </p>
          <dl className="mt-8 grid grid-cols-1 gap-6 border-l border-primary/50 pl-5 text-sm sm:grid-cols-2">
            {s.facts.map((f, i) => (
              <div key={i}>
                <dt className="eyebrow text-muted-foreground">{f.k}</dt>
                <dd className="mt-1 font-display text-lg">{f.v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section
        id="expertise"
        className="relative scroll-mt-20 border-y border-border bg-plum py-24"
      >
        <div className="mx-auto max-w-6xl px-5">
          <p className="eyebrow">Expertise</p>
          <h2 className="mt-3 text-5xl md:text-6xl">
            Our <em className="text-gold">disciplines</em>
          </h2>
          <div className="mt-12 grid overflow-hidden rounded-2xl border border-border sm:grid-cols-2 lg:grid-cols-4">
            {s.disciplines.map((d, k) => (
              <article
                key={k}
                className="border-border bg-background/40 p-8 transition hover:bg-secondary sm:border-r sm:border-b"
              >
                <span className="font-display text-4xl italic text-primary/70">
                  {ROMAN[k] ?? k + 1}
                </span>
                <h3 className="mt-6 text-2xl">{d.t}</h3>
                <p className="mt-3 text-sm font-light leading-relaxed text-muted-foreground">
                  {d.d}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="cases" className="mx-auto max-w-6xl scroll-mt-20 px-5 py-24">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div>
            <p className="eyebrow">Clinical Gallery</p>
            <h2 className="mt-3 text-5xl md:text-6xl">
              Selected <em className="text-gold">cases</em>
            </h2>
          </div>
          <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 lg:mx-0 lg:px-0">
            {cats.map((c) => (
              <button
                key={c}
                onClick={() => {
                  setFilter(c);
                  setOpenId(null);
                }}
                className={`shrink-0 rounded-full border px-4 py-2 text-[0.65rem] uppercase tracking-[0.25em] transition ${filter === c ? "border-transparent bg-gold text-primary-foreground" : "border-border text-muted-foreground hover:text-primary"}`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((c) => (
            <button
              key={c.id}
              aria-label={`Open case: ${c.t}`}
              onClick={() => setOpenId(c.id)}
              className="group text-left"
            >
              <div className="relative aspect-[4/3] overflow-hidden rounded-xl border border-border bg-card">
                {c.img ? (
                  <img
                    src={c.img}
                    alt={c.t}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                  />
                ) : (
                  <div className="grid h-full place-items-center bg-plum font-display text-2xl italic text-muted-foreground">
                    Case photo
                  </div>
                )}
                <span className="absolute left-3 top-3 rounded-full bg-background/80 px-3 py-1 text-[0.6rem] uppercase tracking-[0.25em] text-primary backdrop-blur">
                  {c.c}
                </span>
                {isNew(c) && (
                  <span className="absolute right-3 top-3 rounded-full bg-gold px-3 py-1 text-[0.6rem] uppercase tracking-[0.25em] text-primary-foreground">
                    New
                  </span>
                )}
              </div>
              <h3 className="mt-4 text-2xl">
                <em className="mr-2 text-sm text-primary">
                  No. {String(c.i + 1).padStart(2, "0")}
                </em>
                {c.t}
              </h3>
              <p className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">{c.d}</p>
            </button>
          ))}
        </div>
        {shown.length === 0 && (
          <div className="mt-12 rounded-2xl border border-dashed border-border py-16 text-center text-muted-foreground">
            No cases in this category yet.
          </div>
        )}
      </section>

      {s.principles.length > 0 && (
        <section className="border-t border-border py-24">
          <div className="mx-auto max-w-6xl px-5">
            <p className="eyebrow">The Approach</p>
            <h2 className="mt-3 text-5xl md:text-6xl">
              Our <em className="text-gold">principles</em>
            </h2>
            <div className="mt-12 grid gap-10 md:grid-cols-3">
              {s.principles.map((p, k) => (
                <div key={k}>
                  <div className="flex items-center gap-4">
                    <span className="font-display text-5xl text-primary">
                      {String(k + 1).padStart(2, "0")}
                    </span>
                    <span className="h-px flex-1 bg-border" />
                  </div>
                  <h3 className="mt-5 text-2xl italic">{p.t}</h3>
                  <p className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">
                    {p.d}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      <section
        id="contact"
        className="relative scroll-mt-20 border-t border-border bg-plum py-28 text-center"
      >
        <p className="eyebrow">Appointments</p>
        <h2 className="mx-auto mt-4 max-w-2xl break-words px-4 text-5xl leading-none sm:text-6xl md:text-7xl">
          <em className="text-gold">{s.contact_title}</em>
        </h2>
        <p dir="rtl" className="mt-4 font-arabic text-xl text-muted-foreground">
          احجز موعدك الآن
        </p>
        <a href={tel} className="mt-8 block font-display text-4xl md:text-5xl hover:text-primary">
          {s.phone_label}
        </a>
        <div className="mt-8 flex justify-center gap-3">
          <a
            href={`https://wa.me/${s.phone.replace(/\D/g, "")}`}
            target="_blank"
            rel="noreferrer"
            className="rounded-full bg-gold px-7 py-3 text-xs uppercase tracking-[0.25em] text-primary-foreground shadow-soft"
          >
            WhatsApp
          </a>
          <a
            href={tel}
            className="rounded-full border border-border px-7 py-3 text-xs uppercase tracking-[0.25em] hover:border-primary hover:text-primary"
          >
            Call now
          </a>
        </div>
        <p className="mt-10 eyebrow text-muted-foreground">{s.location}</p>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs uppercase tracking-[0.3em] text-muted-foreground">
        {s.first_name} {s.last_name} · © {new Date().getFullYear()} ·{" "}
        <Link to="/admin" className="hover:text-primary">
          Admin
        </Link>
      </footer>

      {cinema && (
        <CinemaPresentation
          slides={buildSlides(s, cases)}
          seconds={s.presentation.seconds}
          music={s.presentation.music}
          onClose={() => setCinema(false)}
        />
      )}

      {active && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={active.t}
          onClick={() => setOpenId(null)}
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-background/95 p-4 backdrop-blur"
        >
          <div className="flex max-h-full w-full max-w-5xl flex-col items-center py-4">
            {active.img ? (
              <img
                src={active.img}
                alt={active.t}
                className="max-h-[65vh] max-w-full rounded-lg object-contain"
                onClick={(e) => e.stopPropagation()}
              />
            ) : (
              <div className="grid h-64 w-full place-items-center rounded-lg bg-plum font-display text-3xl italic text-muted-foreground">
                Case photo
              </div>
            )}
            <div className="mt-4 max-w-2xl text-center" onClick={(e) => e.stopPropagation()}>
              <p className="eyebrow">{active.c}</p>
              <h3 className="mt-2 font-display text-3xl">{active.t}</h3>
              {active.d && (
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{active.d}</p>
              )}
            </div>
            <div className="mt-5 flex items-center gap-3" onClick={(e) => e.stopPropagation()}>
              <button
                aria-label="Previous case"
                onClick={() => setOpenId(shown[(openIndex - 1 + shown.length) % shown.length]!.id)}
                className="h-11 w-11 rounded-full border border-border hover:text-primary"
              >
                ‹
              </button>
              <button
                autoFocus
                aria-label="Close case"
                onClick={() => setOpenId(null)}
                className="rounded-full bg-gold px-6 py-3 text-xs uppercase tracking-[0.25em] text-primary-foreground"
              >
                Close
              </button>
              <button
                aria-label="Next case"
                onClick={() => setOpenId(shown[(openIndex + 1) % shown.length]!.id)}
                className="h-11 w-11 rounded-full border border-border hover:text-primary"
              >
                ›
              </button>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              {openIndex + 1} / {shown.length}
            </p>
          </div>
        </div>
      )}
    </main>
  );
}
