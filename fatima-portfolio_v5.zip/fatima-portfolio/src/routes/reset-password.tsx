import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "New password — Dr. Fatima Control Panel" },
      { name: "description", content: "Set a new password for the control panel." },
      { property: "og:title", content: "New password — Dr. Fatima Control Panel" },
      { property: "og:description", content: "Set a new password for the control panel." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Reset,
});

function Reset() {
  const nav = useNavigate();
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setBusy(false);
    if (error) return setMsg(error.message);
    nav({ to: "/admin", replace: true });
  };
  return (
    <main
      dir="rtl"
      className="flex min-h-screen items-center justify-center bg-background px-5 text-foreground"
    >
      <form
        onSubmit={save}
        className="w-full max-w-sm rounded-2xl border border-border bg-card p-8"
      >
        <h1 className="font-arabic text-2xl">باسورد جديد</h1>
        <input
          dir="ltr"
          type="password"
          minLength={6}
          required
          value={pw}
          onChange={(e) => setPw(e.target.value)}
          className="mt-6 w-full rounded-lg border border-input bg-background px-3 py-2"
        />
        <button
          disabled={busy}
          className="mt-6 w-full rounded-full bg-gold py-3 text-sm text-primary-foreground disabled:opacity-60"
        >
          {busy ? "جاري الحفظ..." : "حفظ"}
        </button>
        {msg && (
          <p role="alert" className="mt-4 text-sm text-destructive">
            {msg}
          </p>
        )}
      </form>
    </main>
  );
}
