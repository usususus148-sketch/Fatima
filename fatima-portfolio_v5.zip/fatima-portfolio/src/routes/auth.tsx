import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — Dr. Fatima Control Panel" },
      { name: "description", content: "Sign in to manage the dental portfolio." },
      { property: "og:title", content: "Sign in — Dr. Fatima Control Panel" },
      { property: "og:description", content: "Sign in to manage the dental portfolio." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const nav = useNavigate();
  const [mode, setMode] = useState<"in" | "up" | "forgot">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      if (mode === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        nav({ to: "/admin", replace: true });
      } else if (mode === "up") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/admin` },
        });
        if (error) throw error;
        setMsg("اتبعتلك رسالة على الإيميل — افتحيها واضغطي على الرابط عشان تفعّلي الحساب.");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setMsg("اتبعتلك رابط تغيير الباسورد على الإيميل.");
      }
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "حصل خطأ");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main
      dir="rtl"
      className="flex min-h-screen items-center justify-center bg-background bg-plum px-5 text-foreground"
    >
      <form
        onSubmit={submit}
        className="w-full max-w-sm rounded-2xl border border-border bg-card/80 p-8 shadow-soft backdrop-blur"
      >
        <p className="font-script text-4xl text-primary">Dr. Fatima</p>
        <h1 className="mt-2 font-arabic text-2xl">
          {mode === "in" ? "دخول لوحة التحكم" : mode === "up" ? "إنشاء حساب" : "نسيت الباسورد"}
        </h1>
        <label className="mt-6 block text-sm text-muted-foreground">الإيميل</label>
        <input
          dir="ltr"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2"
        />
        {mode !== "forgot" && (
          <>
            <label className="mt-4 block text-sm text-muted-foreground">الباسورد</label>
            <input
              dir="ltr"
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2"
            />
          </>
        )}
        <button
          disabled={busy}
          className="mt-6 w-full rounded-full bg-gold py-3 text-sm text-primary-foreground disabled:opacity-60"
        >
          {busy ? "..." : mode === "in" ? "دخول" : mode === "up" ? "إنشاء الحساب" : "ابعتي الرابط"}
        </button>
        {mode === "up" && (
          <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
            أول حساب بيتعمل هو اللي بياخد صلاحية تعديل الموقع.
          </p>
        )}
        {msg && (
          <p role="status" className="mt-4 text-sm text-primary">
            {msg}
          </p>
        )}
        <div className="mt-6 flex justify-between text-xs text-muted-foreground">
          {mode !== "in" ? (
            <button type="button" onClick={() => setMode("in")}>
              عندي حساب
            </button>
          ) : (
            <button type="button" onClick={() => setMode("up")}>
              إنشاء حساب
            </button>
          )}
          {mode === "in" && (
            <button type="button" onClick={() => setMode("forgot")}>
              نسيت الباسورد؟
            </button>
          )}
        </div>
      </form>
    </main>
  );
}
