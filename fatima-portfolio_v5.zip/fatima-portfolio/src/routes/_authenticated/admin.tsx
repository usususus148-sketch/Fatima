import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { siteContentQuery } from "@/lib/site-content.functions";
import { DEFAULT_CONTENT, THEMES, uid, type SiteContent } from "@/lib/site-content";
import {
  AddBtn,
  Area,
  Card,
  Field,
  ImageField,
  ItemShell,
  Toggle,
} from "@/components/admin/fields";
import { move } from "@/lib/admin-utils";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Control Panel — Dr. Fatima Portfolio" },
      { name: "description", content: "Edit every part of the dental portfolio." },
      { property: "og:title", content: "Control Panel — Dr. Fatima Portfolio" },
      { property: "og:description", content: "Edit every part of the dental portfolio." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

const TABS = [
  ["cases", "الحالات"],
  ["presentation", "البريزنتيشن"],
  ["hero", "الواجهة"],
  ["about", "النبذة"],
  ["expertise", "التخصصات والمبادئ"],
  ["contact", "التواصل"],
  ["theme", "الثيم"],
] as const;
type Tab = (typeof TABS)[number][0];

function Admin() {
  const qc = useQueryClient();
  const nav = useNavigate();
  const { data: loaded } = useQuery(siteContentQuery);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [s, setS] = useState<SiteContent | null>(null);
  const [tab, setTab] = useState<Tab>("cases");
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    document.documentElement.classList.add("scroll-smooth");
  }, []);
  useEffect(() => {
    if (loaded && !s) setS(loaded);
  }, [loaded, s]);
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return setIsAdmin(false);
      const { data: ok } = await supabase.rpc("has_role", {
        _user_id: data.user.id,
        _role: "admin",
      });
      setIsAdmin(!!ok);
    });
  }, []);

  const up = (patch: Partial<SiteContent>) => {
    setS((p) => (p ? { ...p, ...patch } : p));
    setDirty(true);
  };
  const upP = (patch: Partial<SiteContent["presentation"]>) =>
    s && up({ presentation: { ...s.presentation, ...patch } });

  const save = async () => {
    if (!s) return;
    setSaving(true);
    setStatus(null);
    const { error } = await supabase
      .from("site_content")
      .upsert({ id: 1, content: s as unknown as Json, updated_at: new Date().toISOString() });
    setSaving(false);
    if (error) return setStatus("ماتحفظش: " + error.message);
    setDirty(false);
    setStatus("اتحفظ ✓ — التعديلات ظهرت في الموقع");
    qc.setQueryData(siteContentQuery.queryKey, s);
  };

  const signOut = async () => {
    if (dirty && !confirm("في تعديلات لسه ماتحفظتش. عايزة تخرجي من غير حفظ؟")) return;
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    nav({ to: "/auth", replace: true });
  };

  if (isAdmin === false)
    return (
      <main
        dir="rtl"
        className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background p-6 text-center text-foreground"
      >
        <p className="font-arabic text-xl">الحساب ده مش عنده صلاحية تعديل الموقع.</p>
        <button onClick={signOut} className="rounded-full border border-border px-5 py-2 text-sm">
          خروج
        </button>
      </main>
    );
  if (!s || isAdmin === null)
    return (
      <main className="grid min-h-screen place-items-center bg-background text-muted-foreground">
        ...
      </main>
    );

  return (
    <main dir="rtl" className={`theme-${s.theme} min-h-screen bg-background pb-28 text-foreground`}>
      <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <div>
            <p className="font-script text-2xl text-primary">Dr. Fatima</p>
            <p className="text-xs text-muted-foreground">لوحة التحكم</p>
          </div>
          <div className="flex gap-2 text-xs">
            <Link
              to="/"
              onClick={(e) => {
                if (dirty && !confirm("في تعديلات لسه ماتحفظتش. عايزة تفتحي الموقع من غير حفظ؟"))
                  e.preventDefault();
              }}
              className="rounded-full border border-border px-4 py-2"
            >
              عرض الموقع
            </Link>
            <button onClick={signOut} className="rounded-full border border-border px-4 py-2">
              خروج
            </button>
          </div>
        </div>
        <nav className="mx-auto flex max-w-5xl gap-2 overflow-x-auto px-4 pb-3">
          {TABS.map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`shrink-0 rounded-full px-4 py-1.5 text-sm ${tab === id ? "bg-gold text-primary-foreground" : "border border-border text-muted-foreground"}`}
            >
              {label}
            </button>
          ))}
        </nav>
      </header>

      <div className="mx-auto max-w-5xl space-y-6 px-4 py-6">
        {tab === "cases" && (
          <>
            <Card
              title={`الحالات (${s.cases.length})`}
              actions={
                <AddBtn
                  onClick={() =>
                    up({
                      cases: [
                        {
                          id: uid(),
                          t: "حالة جديدة",
                          c: s.categories[0] ?? "",
                          d: "",
                          img: "",
                          added_at: new Date().toISOString(),
                        },
                        ...s.cases,
                      ],
                    })
                  }
                >
                  حالة جديدة
                </AddBtn>
              }
            >
              <p className="text-xs text-muted-foreground">
                الحالة الجديدة بيظهر عليها علامة "New" لمدة أسبوعين، والزوار اللي رجعوا الموقع
                بيظهرلهم تنبيه إن في حالة جديدة.
              </p>
              {s.cases.map((c, i) => {
                const set = (p: Partial<typeof c>) =>
                  up({ cases: s.cases.map((x, k) => (k === i ? { ...x, ...p } : x)) });
                return (
                  <ItemShell
                    key={c.id}
                    onUp={() => up({ cases: move(s.cases, i, -1) })}
                    onDown={() => up({ cases: move(s.cases, i, 1) })}
                    onDelete={() => up({ cases: s.cases.filter((_, k) => k !== i) })}
                  >
                    <div className="grid gap-3 md:grid-cols-2">
                      <Field label="اسم الحالة" value={c.t} onChange={(t) => set({ t })} />
                      <label className="block">
                        <span className="text-xs text-muted-foreground">النوع</span>
                        <select
                          value={c.c}
                          onChange={(e) => set({ c: e.target.value })}
                          className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
                        >
                          {s.categories.map((x) => (
                            <option key={x}>{x}</option>
                          ))}
                        </select>
                      </label>
                    </div>
                    <Area label="الوصف" value={c.d} onChange={(d) => set({ d })} />
                    <label className="block">
                      <span className="text-xs text-muted-foreground">
                        تاريخ إضافة الحالة (بيتحدد عليه علامة New)
                      </span>
                      <input
                        type="date"
                        value={Number.isNaN(Date.parse(c.added_at)) ? "" : c.added_at.slice(0, 10)}
                        onChange={(e) => {
                          if (e.target.value)
                            set({
                              added_at: new Date(`${e.target.value}T12:00:00.000Z`).toISOString(),
                            });
                        }}
                        className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
                      />
                    </label>
                    <ImageField
                      label="صورة الحالة"
                      value={c.img}
                      onChange={(img) => set({ img })}
                    />
                    <Toggle
                      label="إخفاء الحالة من الموقع"
                      value={!!c.hidden}
                      onChange={(hidden) => set({ hidden })}
                    />
                  </ItemShell>
                );
              })}
            </Card>
            <Card
              title="أنواع الحالات (أزرار الفلترة)"
              actions={
                <AddBtn onClick={() => up({ categories: [...s.categories, "نوع جديد"] })}>
                  نوع
                </AddBtn>
              }
            >
              {s.categories.map((c, i) => (
                <div key={i} className="flex items-end gap-2">
                  <div className="flex-1">
                    <Field
                      label={`نوع ${i + 1}`}
                      value={c}
                      onChange={(v) =>
                        up({
                          categories: s.categories.map((x, k) => (k === i ? v : x)),
                          cases: s.cases.map((x) => (x.c === c ? { ...x, c: v } : x)),
                        })
                      }
                    />
                  </div>
                  <button
                    onClick={() => up({ categories: s.categories.filter((_, k) => k !== i) })}
                    className="mb-1 text-xs text-destructive"
                  >
                    حذف
                  </button>
                </div>
              ))}
            </Card>
          </>
        )}

        {tab === "presentation" && (
          <>
            <Card title="إعدادات العرض">
              <Toggle
                label="يفتح لوحده أول ما حد يدخل الموقع"
                value={s.presentation.autoplay}
                onChange={(autoplay) => upP({ autoplay })}
              />
              <Toggle
                label="موسيقى بحيرة البجع"
                value={s.presentation.music}
                onChange={(music) => upP({ music })}
              />
              <label className="block">
                <span className="text-xs text-muted-foreground">
                  مدة كل صفحة: {s.presentation.seconds} ثانية
                </span>
                <input
                  type="range"
                  min={3}
                  max={15}
                  value={s.presentation.seconds}
                  onChange={(e) => upP({ seconds: Number(e.target.value) })}
                  className="mt-2 w-full accent-[var(--primary)]"
                />
              </label>
            </Card>
            <Card title="الصفحات اللي تظهر">
              <Toggle
                label="صفحة الاسم"
                value={s.presentation.show_intro}
                onChange={(show_intro) => upP({ show_intro })}
              />
              <Toggle
                label="صفحة الصورة الشخصية"
                value={s.presentation.show_portrait}
                onChange={(show_portrait) => upP({ show_portrait })}
              />
              <Toggle
                label="صفحات التخصصات"
                value={s.presentation.show_disciplines}
                onChange={(show_disciplines) => upP({ show_disciplines })}
              />
              <Toggle
                label="صفحات الحالات"
                value={s.presentation.show_cases}
                onChange={(show_cases) => upP({ show_cases })}
              />
              <Toggle
                label="صفحة التواصل في الآخر"
                value={s.presentation.show_contact}
                onChange={(show_contact) => upP({ show_contact })}
              />
            </Card>
            <Card
              title="صفحات إضافية"
              actions={
                <AddBtn
                  onClick={() =>
                    upP({
                      extra: [
                        ...s.presentation.extra,
                        {
                          id: uid(),
                          img: "",
                          eyebrow: "",
                          title: "صفحة جديدة",
                          text: "",
                          position: "end",
                        },
                      ],
                    })
                  }
                >
                  صفحة
                </AddBtn>
              }
            >
              {s.presentation.extra.length === 0 && (
                <p className="text-sm text-muted-foreground">مفيش صفحات إضافية لسه.</p>
              )}
              {s.presentation.extra.map((x, i) => {
                const ex = s.presentation.extra;
                const set = (p: Partial<typeof x>) =>
                  upP({ extra: ex.map((y, k) => (k === i ? { ...y, ...p } : y)) });
                return (
                  <ItemShell
                    key={x.id}
                    onUp={() => upP({ extra: move(ex, i, -1) })}
                    onDown={() => upP({ extra: move(ex, i, 1) })}
                    onDelete={() => upP({ extra: ex.filter((_, k) => k !== i) })}
                  >
                    <Field
                      label="العنوان الصغير فوق"
                      value={x.eyebrow}
                      onChange={(eyebrow) => set({ eyebrow })}
                    />
                    <Field label="العنوان" value={x.title} onChange={(title) => set({ title })} />
                    <Area label="الكلام" value={x.text} onChange={(text) => set({ text })} />
                    <ImageField
                      label="صورة الخلفية"
                      value={x.img}
                      onChange={(img) => set({ img })}
                    />
                    <label className="block">
                      <span className="text-xs text-muted-foreground">مكانها</span>
                      <select
                        value={x.position}
                        onChange={(e) => set({ position: e.target.value as "start" | "end" })}
                        className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
                      >
                        <option value="start">في أول العرض</option>
                        <option value="end">قبل صفحة التواصل</option>
                      </select>
                    </label>
                  </ItemShell>
                );
              })}
            </Card>
          </>
        )}

        {tab === "hero" && (
          <Card title="الواجهة">
            <Field label="اللوجو فوق" value={s.brand} onChange={(brand) => up({ brand })} />
            <div className="grid gap-3 md:grid-cols-2">
              <Field
                label="الاسم الأول"
                value={s.first_name}
                onChange={(first_name) => up({ first_name })}
              />
              <Field
                label="باقي الاسم"
                value={s.last_name}
                onChange={(last_name) => up({ last_name })}
              />
            </div>
            <Field
              label="الاسم بالعربي"
              value={s.name_ar}
              onChange={(name_ar) => up({ name_ar })}
            />
            <Field
              label="السطر الصغير فوق الاسم"
              value={s.hero_eyebrow}
              onChange={(hero_eyebrow) => up({ hero_eyebrow })}
            />
            <Area
              label="الجملة تحت الاسم"
              value={s.hero_text}
              onChange={(hero_text) => up({ hero_text })}
            />
            <Field
              label="الجملة العربي"
              value={s.hero_text_ar}
              onChange={(hero_text_ar) => up({ hero_text_ar })}
            />
            <ImageField
              label="صورة الخلفية"
              value={s.hero_image}
              onChange={(hero_image) => up({ hero_image })}
            />
            <Area
              label="الكلمات المتحركة (كل كلمة في سطر)"
              value={s.marquee.join("\n")}
              onChange={(v) =>
                up({
                  marquee: v
                    .split("\n")
                    .map((x) => x.trim())
                    .filter(Boolean),
                })
              }
            />
          </Card>
        )}

        {tab === "about" && (
          <Card
            title="النبذة"
            actions={
              <AddBtn onClick={() => up({ facts: [...s.facts, { k: "عنوان", v: "قيمة" }] })}>
                معلومة
              </AddBtn>
            }
          >
            <ImageField
              label="الصورة الشخصية"
              value={s.portrait}
              onChange={(portrait) => up({ portrait })}
            />
            <Area
              label="الجملة المميزة"
              value={s.about_quote}
              onChange={(about_quote) => up({ about_quote })}
            />
            <Area
              label="النبذة"
              value={s.about_text}
              onChange={(about_text) => up({ about_text })}
            />
            {s.facts.map((f, i) => (
              <ItemShell key={i} onDelete={() => up({ facts: s.facts.filter((_, k) => k !== i) })}>
                <div className="grid gap-3 md:grid-cols-2">
                  <Field
                    label="العنوان"
                    value={f.k}
                    onChange={(k) =>
                      up({ facts: s.facts.map((x, j) => (j === i ? { ...x, k } : x)) })
                    }
                  />
                  <Field
                    label="القيمة"
                    value={f.v}
                    onChange={(v) =>
                      up({ facts: s.facts.map((x, j) => (j === i ? { ...x, v } : x)) })
                    }
                  />
                </div>
              </ItemShell>
            ))}
          </Card>
        )}

        {tab === "expertise" &&
          (["disciplines", "principles"] as const).map((key) => (
            <Card
              key={key}
              title={key === "disciplines" ? "التخصصات" : "المبادئ"}
              actions={
                <AddBtn onClick={() => up({ [key]: [...s[key], { t: "جديد", d: "" }] })}>
                  إضافة
                </AddBtn>
              }
            >
              {s[key].map((d, i) => (
                <ItemShell
                  key={i}
                  onUp={() => up({ [key]: move(s[key], i, -1) })}
                  onDown={() => up({ [key]: move(s[key], i, 1) })}
                  onDelete={() => up({ [key]: s[key].filter((_, k) => k !== i) })}
                >
                  <Field
                    label="العنوان"
                    value={d.t}
                    onChange={(t) =>
                      up({ [key]: s[key].map((x, k) => (k === i ? { ...x, t } : x)) })
                    }
                  />
                  <Area
                    label="الوصف"
                    value={d.d}
                    onChange={(v) =>
                      up({ [key]: s[key].map((x, k) => (k === i ? { ...x, d: v } : x)) })
                    }
                  />
                </ItemShell>
              ))}
            </Card>
          ))}

        {tab === "contact" && (
          <Card title="التواصل">
            <Field
              ltr
              label="رقم التليفون (للاتصال والواتساب)"
              value={s.phone}
              onChange={(phone) => up({ phone })}
            />
            <Field
              ltr
              label="الرقم زي ما يظهر في الموقع"
              value={s.phone_label}
              onChange={(phone_label) => up({ phone_label })}
            />
            <Field
              label="عنوان قسم التواصل"
              value={s.contact_title}
              onChange={(contact_title) => up({ contact_title })}
            />
            <Field label="المكان" value={s.location} onChange={(location) => up({ location })} />
          </Card>
        )}

        {tab === "theme" && (
          <Card title="ثيم الموقع">
            <div className="grid gap-3 sm:grid-cols-3">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => up({ theme: t.id })}
                  className={`rounded-xl border p-4 text-right ${s.theme === t.id ? "border-primary ring-2 ring-primary" : "border-border"}`}
                >
                  <div className="flex h-12 overflow-hidden rounded-lg">
                    {t.colors.map((c) => (
                      <span key={c} className="flex-1" style={{ background: c }} />
                    ))}
                  </div>
                  <p className="mt-3 text-sm">{t.label}</p>
                </button>
              ))}
            </div>
          </Card>
        )}

        <button
          onClick={() => {
            if (confirm("هترجعي كل حاجة للمحتوى الأصلي؟")) {
              setS(DEFAULT_CONTENT);
              setDirty(true);
            }
          }}
          className="text-xs text-muted-foreground hover:text-destructive"
        >
          رجوع للمحتوى الأصلي
        </button>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <p role="status" className="text-xs text-muted-foreground">
            {status ?? (dirty ? "في تعديلات لسه ماتحفظتش" : "كل حاجة محفوظة")}
          </p>
          <button
            onClick={save}
            disabled={saving || !dirty}
            className="rounded-full bg-gold px-8 py-2.5 text-sm text-primary-foreground shadow-soft disabled:opacity-50"
          >
            {saving ? "جاري الحفظ..." : "حفظ"}
          </button>
        </div>
      </div>
    </main>
  );
}
