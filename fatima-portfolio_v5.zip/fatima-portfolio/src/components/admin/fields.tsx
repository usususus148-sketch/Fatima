import { useState, type ReactNode } from "react";
import { uploadImage } from "@/lib/admin-utils";

const box = "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm";

export function Field({
  label,
  value,
  onChange,
  ltr,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  ltr?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <input
        dir={ltr ? "ltr" : "auto"}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={box}
      />
    </label>
  );
}
export function Area({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <textarea
        dir="auto"
        rows={3}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={box}
      />
    </label>
  );
}
export function Toggle({
  label,
  value,
  onChange,
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-border px-3 py-2 text-sm">
      <span>{label}</span>
      <input
        type="checkbox"
        checked={value}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4 w-4 accent-[var(--primary)]"
      />
    </label>
  );
}

export function ImageField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  return (
    <div>
      <span className="text-xs text-muted-foreground">{label}</span>
      <div className="mt-1 flex items-center gap-3">
        {value ? (
          <img
            src={value}
            alt=""
            className="h-16 w-20 rounded-md border border-border object-cover"
          />
        ) : (
          <div className="grid h-16 w-20 place-items-center rounded-md border border-dashed border-border text-xs text-muted-foreground">
            بدون صورة
          </div>
        )}
        <label className="cursor-pointer rounded-full border border-border px-4 py-2 text-xs hover:border-primary hover:text-primary">
          {busy ? "جاري الرفع..." : value ? "تغيير الصورة" : "رفع صورة"}
          <input
            type="file"
            accept="image/*"
            disabled={busy}
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              setBusy(true);
              setErr(null);
              try {
                onChange(await uploadImage(f));
              } catch (x) {
                setErr(x instanceof Error ? x.message : "فشل الرفع");
              } finally {
                setBusy(false);
                e.target.value = "";
              }
            }}
          />
        </label>
        {value && (
          <button
            type="button"
            onClick={() => onChange("")}
            className="text-xs text-muted-foreground hover:text-destructive"
          >
            إزالة
          </button>
        )}
      </div>
      {err && <p className="mt-1 text-xs text-destructive">{err}</p>}
    </div>
  );
}

export function Card({
  title,
  children,
  actions,
}: {
  title: string;
  children: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-border bg-card/60 p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="font-arabic text-xl text-primary">{title}</h2>
        {actions}
      </div>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

export function ItemShell({
  children,
  onUp,
  onDown,
  onDelete,
}: {
  children: ReactNode;
  onUp?: () => void;
  onDown?: () => void;
  onDelete: () => void;
}) {
  return (
    <div className="rounded-xl border border-border bg-background/40 p-4">
      <div className="mb-3 flex justify-end gap-2 text-xs">
        {onUp && (
          <button
            type="button"
            onClick={onUp}
            className="rounded-full border border-border px-3 py-1"
          >
            ↑
          </button>
        )}
        {onDown && (
          <button
            type="button"
            onClick={onDown}
            className="rounded-full border border-border px-3 py-1"
          >
            ↓
          </button>
        )}
        <button
          type="button"
          onClick={() => {
            if (confirm("متأكدة إنك عايزة تحذفي ده؟")) onDelete();
          }}
          className="rounded-full border border-destructive/50 px-3 py-1 text-destructive"
        >
          حذف
        </button>
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

export const AddBtn = ({ onClick, children }: { onClick: () => void; children: ReactNode }) => (
  <button
    type="button"
    onClick={onClick}
    className="rounded-full bg-gold px-4 py-1.5 text-xs text-primary-foreground"
  >
    + {children}
  </button>
);
