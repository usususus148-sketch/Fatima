// Soft Swan Lake theme (Tchaikovsky, public domain) synthesized live: slow oboe-like melody over a deep B-minor pad.
export function startAmbient() {
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new Ctx();
  const VOL = 0.2;
  const master = ctx.createGain(); master.gain.value = 0;
  master.gain.linearRampToValueAtTime(VOL, ctx.currentTime + 4);
  const delay = ctx.createDelay(); delay.delayTime.value = 0.6;
  const fb = ctx.createGain(); fb.gain.value = 0.45;
  const lp = ctx.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 1800;
  delay.connect(fb).connect(delay);
  lp.connect(master); lp.connect(delay); delay.connect(master);
  master.connect(ctx.destination);

  const N: Record<string, number> = { G3: 196, B3: 246.94, "C#4": 277.18, D4: 293.66, E4: 329.63, "F#4": 369.99, G4: 392, B2: 123.47, G2: 98, D3: 146.83, "F#3": 185 };
  const beat = 0.75;
  // [note, beats]
  const melody: [string, number][] = [
    ["F#4", 4], ["B3", 1], ["C#4", 1], ["D4", 1], ["E4", 1], ["F#4", 3], ["D4", 1], ["F#4", 3], ["D4", 1], ["F#4", 3],
    ["B3", 1], ["D4", 1], ["B3", 1], ["G3", 1], ["D4", 1], ["B3", 6],
  ];
  const pads = [["B2", "F#3", "D4"], ["G2", "D3", "B3"], ["B2", "F#3", "D4"], ["G2", "D3", "B3"]];
  const total = melody.reduce((a, [, b]) => a + b, 0) * beat;

  const note = (f: number, t: number, d: number, v: number, type: OscillatorType) => {
    const o = ctx.createOscillator(); o.type = type; o.frequency.value = f;
    const vib = ctx.createOscillator(); vib.frequency.value = 5; const vg = ctx.createGain(); vg.gain.value = type === "triangle" ? 2 : 0;
    vib.connect(vg).connect(o.frequency);
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(v, t + Math.min(0.4, d / 3)); g.gain.linearRampToValueAtTime(0, t + d + 0.6);
    o.connect(g).connect(lp); o.start(t); vib.start(t); o.stop(t + d + 0.8); vib.stop(t + d + 0.8);
  };
  const play = () => {
    let t = ctx.currentTime + 0.1;
    const start = t;
    melody.forEach(([n, b]) => { note(N[n]!, t, b * beat, 0.09, "triangle"); t += b * beat; });
    const seg = total / pads.length;
    pads.forEach((ch, k) => ch.forEach((n) => note(N[n]!, start + k * seg, seg, 0.05, "sine")));
  };
  play(); const timer = window.setInterval(play, (total + 1.5) * 1000);
  const resume = () => ctx.resume();
  window.addEventListener("pointerdown", resume, { once: true });

  return {
    setMuted(m: boolean) { master.gain.cancelScheduledValues(ctx.currentTime); master.gain.linearRampToValueAtTime(m ? 0 : VOL, ctx.currentTime + 0.6); if (!m) ctx.resume(); },
    stop() {
      window.removeEventListener("pointerdown", resume);
      master.gain.cancelScheduledValues(ctx.currentTime);
      master.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.5);
      window.clearInterval(timer); setTimeout(() => ctx.close(), 1800);
    },
  };
}
