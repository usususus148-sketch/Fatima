import { startAmbient } from "./ambientMusic";
import { useEffect, useRef, useState, type ReactNode } from "react";

export type Slide = {
  img?: string | undefined;
  eyebrow?: string;
  title: ReactNode;
  text?: ReactNode;
  contain?: boolean;
};

export function CinemaPresentation({
  slides,
  onClose,
  seconds = 8,
  music = true,
}: {
  slides: Slide[];
  onClose: () => void;
  seconds?: number;
  music?: boolean;
}) {
  const DURATION = Math.max(2, seconds) * 1000;
  const [i, setI] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [progress, setProgress] = useState(0);

  const [muted, setMuted] = useState(false);
  const player = useRef<ReturnType<typeof startAmbient> | null>(null);
  useEffect(() => {
    if (!music) return;
    try {
      player.current = startAmbient();
    } catch {
      /* The presentation still works without audio. */
    }
    return () => player.current?.stop();
  }, [music]);
  useEffect(() => {
    player.current?.setMuted(muted);
  }, [muted]);
  const elapsed = useRef(0);
  const [prev, setPrev] = useState<number | null>(null);
  const last = useRef(0);
  useEffect(() => {
    elapsed.current = 0;
    setProgress(0);
    if (last.current !== i) {
      setPrev(last.current);
      last.current = i;
    }
    const t = setTimeout(() => setPrev(null), 3100);
    return () => clearTimeout(t);
  }, [i]);

  useEffect(() => {
    if (!playing) return;
    const start = performance.now() - elapsed.current;
    let raf = 0;
    const tick = (t: number) => {
      elapsed.current = t - start;
      const p = Math.min(elapsed.current / DURATION, 1);
      setProgress(p);
      if (p >= 1) {
        if (i < slides.length - 1) setI(i + 1);
        else onClose();
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i, playing]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setI((v) => Math.min(v + 1, slides.length - 1));
      if (e.key === "ArrowLeft") setI((v) => Math.max(v - 1, 0));
      if (e.key === " ") {
        e.preventDefault();
        setPlaying((p) => !p);
      }
    };
    const previousOverflow = document.body.style.overflow;
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [onClose, slides.length]);

  useEffect(() => {
    if (slides.length === 0) onClose();
  }, [slides.length, onClose]);
  if (slides.length === 0) return null;

  const renderLayer = (k: number, out: boolean) => {
    const s = slides[k]!;
    return (
      <div
        key={`${k}-${out ? "o" : "i"}`}
        className={`absolute inset-0 ${out ? "animate-cine-out" : "animate-cine-fade"}`}
      >
        {s.img ? (
          s.contain ? (
            <>
              <img
                src={s.img}
                alt=""
                className="absolute inset-0 h-full w-full scale-110 object-cover opacity-25 blur-2xl"
              />
              <img
                src={s.img}
                alt=""
                className="absolute inset-x-4 top-[12%] mx-auto h-[48%] w-[calc(100%-2rem)] animate-ken-burns object-contain md:top-[10%] md:h-[55%]"
              />
            </>
          ) : (
            <img
              src={s.img}
              alt=""
              className="absolute inset-0 h-full w-full animate-ken-burns object-cover opacity-60"
            />
          )
        ) : (
          <div className="absolute inset-0 bg-plum" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/75 to-transparent" />
        <div
          className={`absolute inset-x-0 px-6 text-center ${s.contain ? "bottom-28" : "top-1/2 -translate-y-1/2"}`}
        >
          {s.eyebrow && <p className="eyebrow animate-cine-rise">{s.eyebrow}</p>}
          <div className="mx-auto mt-4 h-px w-24 bg-primary/60 animate-cine-rise" />
          <h2 className="mx-auto mt-5 max-w-3xl font-display text-4xl leading-tight animate-cine-rise [animation-delay:200ms] md:text-7xl">
            {s.title}
          </h2>
          {s.text && (
            <div className="mx-auto mt-4 max-w-xl text-sm font-light leading-relaxed text-muted-foreground animate-cine-rise [animation-delay:400ms] md:text-base">
              {s.text}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div
      className="fixed inset-0 z-[60] overflow-hidden bg-background"
      role="dialog"
      aria-modal="true"
      aria-label="Presentation"
    >
      {prev !== null && prev !== i && renderLayer(prev, true)}
      {renderLayer(i, false)}

      {/* letterbox bars */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[6vh] bg-background" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[6vh] bg-background" />

      <div className="absolute inset-x-0 top-4 flex items-center gap-3 px-4 md:px-10">
        <div className="flex flex-1 gap-1">
          {slides.map((_, k) => (
            <button
              key={k}
              aria-label={`Slide ${k + 1}`}
              onClick={() => setI(k)}
              className="h-4 flex-1"
            >
              <span className="block h-0.5 overflow-hidden rounded bg-foreground/20">
                <span
                  className="block h-full bg-gold"
                  style={{ width: k < i ? "100%" : k === i ? `${progress * 100}%` : "0%" }}
                />
              </span>
            </button>
          ))}
        </div>
        {music && (
          <button
            aria-label={muted ? "Unmute music" : "Mute music"}
            onClick={() => setMuted(!muted)}
            className="h-8 w-8 rounded-full border border-border bg-background/60 text-sm"
          >
            {muted ? "🔇" : "♪"}
          </button>
        )}
        <button
          onClick={onClose}
          className="rounded-full border border-border bg-background/60 px-4 py-1.5 text-[0.65rem] uppercase tracking-[0.3em]"
        >
          Skip ✕
        </button>
      </div>

      <div className="absolute inset-x-0 bottom-6 flex items-center justify-center gap-3">
        <button
          aria-label="Previous"
          onClick={() => setI(Math.max(i - 1, 0))}
          className="h-11 w-11 rounded-full border border-border bg-background/60"
        >
          ‹
        </button>
        <button
          aria-label={playing ? "Pause" : "Play"}
          onClick={() => setPlaying(!playing)}
          className="h-12 w-12 rounded-full bg-gold text-primary-foreground shadow-soft"
        >
          {playing ? "❚❚" : "▶"}
        </button>
        <button
          aria-label="Next"
          onClick={() => (i < slides.length - 1 ? setI(i + 1) : onClose())}
          className="h-11 w-11 rounded-full border border-border bg-background/60"
        >
          ›
        </button>
        <span className="ml-2 font-display text-sm italic text-muted-foreground">
          {String(i + 1).padStart(2, "0")} / {slides.length}
        </span>
      </div>
    </div>
  );
}
