import { describe, expect, it } from "vitest";
import { isNew, withDefaults, DEFAULT_CONTENT } from "@/lib/site-content";

describe("site content", () => {
  it("marks a case as new for 14 days only", () => {
    const now = new Date("2026-11-20T00:00:00Z").getTime();
    const c = { ...DEFAULT_CONTENT.cases[0]!, added_at: "2026-11-10T00:00:00Z" };
    expect(isNew(c, now)).toBe(true);
    expect(isNew({ ...c, added_at: "2026-11-01T00:00:00Z" }, now)).toBe(false);
  });
  it("falls back to defaults when nothing is saved", () => {
    expect(withDefaults(null).cases).toHaveLength(10);
    expect(withDefaults({ theme: "rose" }).presentation.seconds).toBe(8);
  });
});
