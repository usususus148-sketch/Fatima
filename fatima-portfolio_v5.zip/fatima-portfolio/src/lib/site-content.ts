import portrait from "@/assets/dentist_portrait.jpg.asset.json";
import heroTooth from "@/assets/hero-tooth.jpg.asset.json";
import smile from "@/assets/smile-restored.jpg.asset.json";
import rctUpper from "@/assets/single-visit-rct-upper-lateral.jpg.asset.json";
import gingival from "@/assets/gingival-depigmentation.jpg.asset.json";
import bridge from "@/assets/bridge-step-by-step.jpg.asset.json";
import mod from "@/assets/mod-back-to-back.jpg.asset.json";
import anterior from "@/assets/esthetic-anterior-composite.jpg.asset.json";
import deepXray from "@/assets/deep-margin-xray.jpg.asset.json";
import fixed from "@/assets/fixed-prosthesis-bridge.jpg.asset.json";
import deepActions from "@/assets/deep-margin-actions.jpg.asset.json";
import rctLower from "@/assets/rct-lower-anterior.jpg.asset.json";

export type ThemeId = "gold" | "rose" | "navy";
export const THEMES: { id: ThemeId; label: string; colors: string[] }[] = [
  { id: "gold", label: "أسود وذهبي", colors: ["#1f1418", "#d9b26a", "#f3ece0"] },
  { id: "rose", label: "أبيض ووردي ناعم", colors: ["#fbf6f3", "#b76e79", "#3a2a2e"] },
  { id: "navy", label: "كحلي وفضي", colors: ["#0f1a2b", "#c9d1dc", "#f4f6f9"] },
];

export type CaseItem = { id: string; t: string; c: string; d: string; img: string; added_at: string; hidden?: boolean };
export type TextPair = { t: string; d: string };
export type ExtraSlide = { id: string; img: string; eyebrow: string; title: string; text: string; position: "start" | "end" };

export type SiteContent = {
  theme: ThemeId;
  brand: string;
  first_name: string;
  last_name: string;
  name_ar: string;
  hero_eyebrow: string;
  hero_text: string;
  hero_text_ar: string;
  hero_image: string;
  portrait: string;
  about_quote: string;
  about_text: string;
  facts: { k: string; v: string }[];
  marquee: string[];
  disciplines: TextPair[];
  categories: string[];
  cases: CaseItem[];
  principles: TextPair[];
  phone: string;
  phone_label: string;
  location: string;
  contact_title: string;
  presentation: {
    autoplay: boolean;
    seconds: number;
    music: boolean;
    show_intro: boolean;
    show_portrait: boolean;
    show_disciplines: boolean;
    show_cases: boolean;
    show_contact: boolean;
    extra: ExtraSlide[];
  };
};

const day = "2026-11-01T00:00:00.000Z";
export const DEFAULT_CONTENT: SiteContent = {
  theme: "gold",
  brand: "Dr. Fatima",
  first_name: "Fatima",
  last_name: "Elzahraa Ahmed",
  name_ar: "د. فاطمة الزهراء أحمد",
  hero_eyebrow: "Dental Intern · Minya University",
  hero_text: "Restoring function, sealing margins and shaping smiles — with the patience of a craftsman and the precision of science.",
  hero_text_ar: "ابتسامتك… فنٌّ يُصنع بدقّة",
  hero_image: heroTooth.url,
  portrait: portrait.url,
  about_quote: "A dedicated professional dentist — and a fast, perceptive learner.",
  about_text: "Skillful in the branches of endodontics, operative dentistry, pedodontics and oral surgery. A graduate of the Faculty of Dentistry, Minya University, documenting every case from the first radiograph to the final result — always under isolation, always verified on X-ray.",
  facts: [
    { k: "Role", v: "Dental Intern (Imtiyaz)" },
    { k: "Education", v: "Faculty of Dentistry, Minya University" },
    { k: "Based in", v: "Minya, Egypt" },
    { k: "Focus", v: "Endo · Operative · Pedo · Surgery" },
  ],
  marquee: ["Endodontics", "Operative", "Pedodontics", "Oral Surgery", "Fixed Prosthesis", "Gingival Esthetics", "Rubber-Dam Isolation"],
  disciplines: [
    { t: "Endodontics", d: "Root canal treatment — including single-visit cases — sealed to the apex." },
    { t: "Operative", d: "Deep-margin Class II and MOD restorations, matrix techniques and a reliable seal." },
    { t: "Pedodontics", d: "Gentle, patient care that helps children feel safe and confident in the chair." },
    { t: "Oral Surgery", d: "Extractions and minor surgical procedures performed calmly and safely." },
  ],
  categories: ["Prosthodontics", "Endodontics", "Restorative", "Perio & Esthetics"],
  cases: [
    { id: "c1", t: "Smile Restored", c: "Prosthodontics", d: "A missing posterior segment rebuilt with a fixed restoration that blends into the arch.", img: smile.url, added_at: day },
    { id: "c2", t: "Single-Visit RCT", c: "Endodontics", d: "Root canal treatment for a badly destructed upper lateral incisor, completed in one visit.", img: rctUpper.url, added_at: day },
    { id: "c3", t: "Gingival Depigmentation", c: "Perio & Esthetics", d: "Dark melanin-pigmented gums treated to reveal an even, healthy pink tissue tone.", img: gingival.url, added_at: day },
    { id: "c4", t: "The Bridge, Step by Step", c: "Prosthodontics", d: "From clinical state to final prosthesis — old amalgam replaced with composite, reduction and retraction cord in a single session.", img: bridge.url, added_at: day },
    { id: "c5", t: "Back-to-Back MOD", c: "Restorative", d: "Deep margins nearly at bone level, managed with the saddle matrix technique for a perfect seal.", img: mod.url, added_at: day },
    { id: "c6", t: "Anterior Esthetics", c: "Perio & Esthetics", d: "Stained, carious front teeth restored with layered composite under full isolation.", img: anterior.url, added_at: day },
    { id: "c7", t: "Deep Margin Seal", c: "Restorative", d: "An upper molar with a deep infrabony pocket and a challenging subgingival Class II margin — sealed.", img: deepXray.url, added_at: day },
    { id: "c8", t: "Fixed Prosthesis", c: "Prosthodontics", d: "Abutments prepared and finished into a seamless posterior bridge.", img: fixed.url, added_at: day },
    { id: "c9", t: "Perio-Restorative Approach", c: "Restorative", d: "Periodontal phase first — curettage and defect debridement — then a conservative Class II restoration.", img: deepActions.url, added_at: day },
    { id: "c10", t: "Root Canal Treatment", c: "Endodontics", d: "A lower anterior tooth treated from access cavity under rubber dam to final obturation.", img: rctLower.url, added_at: day },
  ],
  principles: [
    { t: "Isolation", d: "Rubber dam and careful retraction on every case — a clean field is the first step to a lasting result." },
    { t: "Precision", d: "Each step verified on radiograph: from the initial file to the final seal at the apex and the margin." },
    { t: "Conservation", d: "Preserve what is healthy. Minimal, thoughtful preparation that respects natural tooth structure." },
  ],
  phone: "+201064277161",
  phone_label: "+20 106 427 7161",
  location: "Minya, Egypt · المنيا",
  contact_title: "Let’s design your smile",
  presentation: {
    autoplay: true, seconds: 8, music: true,
    show_intro: true, show_portrait: true, show_disciplines: true, show_cases: true, show_contact: true,
    extra: [],
  },
};

export function withDefaults(raw: unknown): SiteContent {
  const r = (raw && typeof raw === "object" ? raw : {}) as Partial<SiteContent>;
  return { ...DEFAULT_CONTENT, ...r, presentation: { ...DEFAULT_CONTENT.presentation, ...(r.presentation ?? {}) } };
}

export const NEW_DAYS = 14;
export function isNew(c: CaseItem, now = Date.now()) {
  return now - new Date(c.added_at).getTime() < NEW_DAYS * 86400000;
}
export const uid = () => Math.random().toString(36).slice(2, 10);
