import { supabase } from "@/integrations/supabase/client";

const MAX_IMAGE_SIZE = 15 * 1024 * 1024;
const MAX_IMAGE_EDGE = 2400;

async function optimizeImage(file: File): Promise<File> {
  if (!file.type.startsWith("image/")) throw new Error("اختاري ملف صورة.");
  if (file.size > MAX_IMAGE_SIZE) throw new Error("الصورة أكبر من 15 ميجا. اختاري صورة أصغر.");

  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error("الصورة دي مش مدعومة. جرّبي JPG أو PNG."));
      image.src = url;
    });
    const scale = Math.min(1, MAX_IMAGE_EDGE / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("المتصفح مقدرش يجهّز الصورة.");
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, "image/webp", 0.92),
    );
    if (!blob) throw new Error("المتصفح مقدرش يجهّز الصورة.");
    if (
      blob.size >= file.size &&
      scale === 1 &&
      ["image/jpeg", "image/png", "image/webp"].includes(file.type)
    )
      return file;
    return new File([blob], "case-photo.webp", { type: "image/webp" });
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function uploadImage(file: File): Promise<string> {
  const optimized = await optimizeImage(file);
  const id =
    typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const extension =
    optimized.type === "image/webp"
      ? "webp"
      : optimized.name
          .split(".")
          .pop()
          ?.replace(/[^a-zA-Z0-9]/g, "") || "jpg";
  const path = `${id}.${extension}`;
  const { error } = await supabase.storage
    .from("media")
    .upload(path, optimized, { contentType: optimized.type });
  if (error) throw error;
  const { data, error: signedError } = await supabase.storage
    .from("media")
    .createSignedUrl(path, 60 * 60 * 24 * 365 * 20);
  if (signedError || !data)
    throw signedError ?? new Error("الصورة اترفعت، لكن مقدرناش نجهّز رابطها.");
  return data.signedUrl;
}

export function move<T>(arr: T[], i: number, d: number): T[] {
  const j = i + d;
  if (j < 0 || j >= arr.length) return arr;
  const a = [...arr];
  [a[i], a[j]] = [a[j]!, a[i]!];
  return a;
}
