# Roadmap
- [x] Dentist portfolio in old site style
- [x] Cinematic presentation (film style)
- [x] Soft background music for the presentation with mute button
- [x] Review and harden public gallery, presentation and admin editing
- [x] Verify desktop/mobile flows, tests and build status
- [x] Package the complete clean source project as a ZIP
- [x] Verify every page, case and presentation slide in all themes at phone and desktop widths
